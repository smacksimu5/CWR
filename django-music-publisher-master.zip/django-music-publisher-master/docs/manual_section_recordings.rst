Section: Recordings
_____________________

This section contains the model ``Recordings`` and
closely related models ``Performing Artists`` and ``Music Labels``.

.. toctree::
   :maxdepth: 2

   manual_recording
   manual_artist
   manual_label
