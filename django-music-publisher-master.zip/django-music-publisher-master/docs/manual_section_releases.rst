Section: Releases
_____________________

This section contains the models related to releases.

.. toctree::
   :maxdepth: 2

   manual_commercialrelease
   manual_libraryrelease
   manual_library
