User Manual
############

.. note::
   This user manual applies to version |version|.

.. toctree::
   :maxdepth: 2

   manual_home
   manual_useradmin
   manual_section_works
   manual_section_recordings
   manual_section_releases



