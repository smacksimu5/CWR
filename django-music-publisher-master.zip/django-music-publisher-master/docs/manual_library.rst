Libraries
====================

.. figure:: /images/libraries.png
   :width: 100%

Label model only has a single field: ``name``.

However, the list views have counters with links:

* for :doc:`works <manual_work>` in this library,
* for :doc:`library releases <manual_libraryrelease>` in this library.
