"""
Template tags for :mod:`music_publisher`
"""
