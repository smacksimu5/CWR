"""
Django-Music-Publisher (DMP) is open source software for managing music
metadata, registration/licencing of musical works and royalty processing.

:mod:`music_publisher` app is the only Django app in this project.
"""
